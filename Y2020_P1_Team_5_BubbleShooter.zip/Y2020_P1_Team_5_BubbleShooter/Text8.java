import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Text8 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text8 extends Foreground
{
    /**
     * Act - do whatever the Text8 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setImage(new GreenfootImage("Level 2", 30,Color.PINK,Color.BLACK));
    }    
}
