import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Text7 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Text7 extends Foreground
{
    /**
     * Act - do whatever the Text7 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setImage(new GreenfootImage("Level 1", 30,Color.PINK,Color.BLACK));
    }    
}
